let cells = document.querySelectorAll('#field td');
