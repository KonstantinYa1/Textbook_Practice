// Получаем ссылку на тело таблицы
var tableBody = document.getElementById('tableBody');

// Цикл для создания 5 строк
for (var i = 1; i <= 5; i++) {
    // Создаем новую строку
    var row = document.createElement('tr');

    // Создаем ячейку для номера строки
    var th = document.createElement('th');
    th.textContent = i;
    row.appendChild(th);

    // Цикл для создания 5 столбцов в каждой строке
    for (var j = 1; j <= 5; j++) {
        // Создаем новую ячейку
        var td = document.createElement('td');
        // Заполняем ячейку произведением номера строки на номер столбца
        
        // Добавляем ячейку в текущую строку
        row.appendChild(td);
    }

    // Добавляем строку в тело таблицы
    tableBody.appendChild(row);
}
