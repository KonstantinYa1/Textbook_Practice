        // Предсказания
        const predictions = [
            { text: "Сегодня удачный день для новых начинаний.", type: "good" },
            { text: "Остерегайтесь непредвиденных ситуаций.", type: "bad" },
            { text: "Вам удастся достичь поставленных целей.", type: "good" },
            { text: "Будьте внимательны в финансовых вопросах.", type: "bad" },
            // Добавьте свои предсказания
        ];

        let predictionTimer;
        let predictionIndex;

        function startPrediction() {
            const timerElement = document.getElementById('timer');
            const textElement = document.getElementById('text');
            const startButton = document.getElementById('start');
            const stopButton = document.getElementById('stop');

            startButton.classList.remove('active');
            stopButton.classList.add('active');
            timerElement.textContent = "0";

            predictionTimer = setInterval(() => {
                timerElement.textContent = parseInt(timerElement.textContent) + 1;
            }, 100);

            // Выбираем случайное предсказание
            predictionIndex = Math.floor(Math.random() * predictions.length);
            textElement.textContent = predictions[predictionIndex].text;
        }

        function stopPrediction() {
            const timerElement = document.getElementById('timer');
            const textElement = document.getElementById('text');
            const stopButton = document.getElementById('stop');

            clearInterval(predictionTimer);
            stopButton.classList.remove('active');
            timerElement.textContent = "?";
            textElement.textContent = predictions[predictionIndex].text;

            // Окрашиваем текст в соответствии с типом предсказания
            const predictionType = predictions[predictionIndex].type;
            textElement.className = predictionType;
        }