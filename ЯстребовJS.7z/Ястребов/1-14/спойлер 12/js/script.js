document.addEventListener('DOMContentLoaded', function () {
    const spoilers = document.querySelectorAll('.spoiler');
    const toggles = document.querySelectorAll('.toggle');

    toggles.forEach((toggle, index) => {
        toggle.addEventListener('click', function () {
            spoilers[index].classList.toggle('active');
        });
    });
});