const horoscopes = {
    'Овен': {
      today: 'Гороскоп для Овна на сегодня...',
      tomorrow: 'Гороскоп для Овна на завтра...',
      afterTomorrow: 'Гороскоп для Овна послезавтра...'
    },
  };
  document.addEventListener('DOMContentLoaded', function () {
    const inputDate = document.getElementById('inputDate');
    const todayRadio = document.getElementById('todayRadio');
    const tomorrowRadio = document.getElementById('tomorrowRadio');
    const afterTomorrowRadio = document.getElementById('afterTomorrowRadio');
    const resultContainer = document.getElementById('horoscopeResult');
  
    inputDate.addEventListener('keydown', function (event) {
      if (event.key === 'Enter') {
        showHoroscope();
      }
    });
  
    todayRadio.addEventListener('change', showHoroscope);
    tomorrowRadio.addEventListener('change', showHoroscope);
    afterTomorrowRadio.addEventListener('change', showHoroscope);
  
    function showHoroscope() {
      const selectedSign = getSelectedSign(); 
      const selectedDay = getSelectedDay(); 
      const horoscope = horoscopes[selectedSign][selectedDay];
      resultContainer.textContent = horoscope;
    }
  });
  function getSelectedSign() {
    const signRadios = document.getElementsByName('sign');
    for (const radio of signRadios) {
      if (radio.checked) {
        return radio.value;
      }
    }
  }
  
  function getSelectedDay() {
    if (todayRadio.checked) {
      return 'today';
    } else if (tomorrowRadio.checked) {
      return 'tomorrow';
    } else if (afterTomorrowRadio.checked) {
      return 'afterTomorrow';
    }
  }
    