document.addEventListener('DOMContentLoaded', function () {
    const tabLinks = document.querySelectorAll('.tab .link a');
  
    tabLinks.forEach(function (link) {
      link.addEventListener('click', function (event) {
        event.preventDefault();
  
        const tabs = document.querySelectorAll('.tab');
        tabs.forEach(function (tab) {
          tab.classList.remove('active');
        });
  
        const tab = link.closest('.tab');
        tab.classList.add('active');
      });
    });
  });
  