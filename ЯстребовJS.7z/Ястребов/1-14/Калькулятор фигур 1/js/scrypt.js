document.addEventListener('DOMContentLoaded', function () {
    let s1 = document.getElementById('s1');
    let s2 = document.getElementById('s2');
    let rectLength = document.getElementById('rectLength');
    let rectWidth = document.getElementById('rectWidth');
    let circleRadius = document.getElementById('circleRadius');
    let triSideA = document.getElementById('triSideA');
    let triSideB = document.getElementById('triSideB');
    let triSideC = document.getElementById('triSideC');

    let b1 = document.getElementById('b1');
    let b2 = document.getElementById('b2');
    let b3 = document.getElementById('b3');
    let b4 = document.getElementById('b4');

    b1.addEventListener('click', startCalculateCvadrat);
    b2.addEventListener('click', startCalculateRectangle);
    b3.addEventListener('click', startCalculateCircle);
    b4.addEventListener('click', startCalculateTriangle);

    function startCalculateCvadrat() {
        let sideA = parseFloat(s1.value);
        let sideB = parseFloat(s2.value);

        if (!isNaN(sideA) && !isNaN(sideB)) {
            let area = sideA * sideB;
            let perimeter = 2 * (sideA + sideB);
            alert(`Площадь: ${area}, Периметр: ${perimeter}`);
        } else {
            alert('Пожалуйста, введите числовые значения для сторон.');
        }
    }

    function startCalculateRectangle() {
        let length = parseFloat(rectLength.value);
        let width = parseFloat(rectWidth.value);

        if (!isNaN(length) && !isNaN(width)) {
            let area = length * width;
            let perimeter = 2 * (length + width);
            alert(`Площадь: ${area}, Периметр: ${perimeter}`);
        } else {
            alert('Пожалуйста, введите числовые значения для длины и ширины.');
        }
    }

    function startCalculateCircle() {
        let radius = parseFloat(circleRadius.value);

        if (!isNaN(radius)) {
            let area = Math.PI * radius ** 2;
            let circumference = 2 * Math.PI * radius;
            alert(`Площадь: ${area}, Длина окружности: ${circumference}`);
        } else {
            alert('Пожалуйста, введите числовое значение для радиуса.');
        }
    }

    function startCalculateTriangle() {
        let sideA = parseFloat(triSideA.value);
        let sideB = parseFloat(triSideB.value);
        let sideC = parseFloat(triSideC.value);

        if (!isNaN(sideA) && !isNaN(sideB) && !isNaN(sideC)) {
            let perimeter = sideA + sideB + sideC;
            let semiPerimeter = perimeter / 2;
            let area = Math.sqrt(semiPerimeter * (semiPerimeter - sideA) * (semiPerimeter - sideB) * (semiPerimeter - sideC));

            alert(`Периметр: ${perimeter}, Площадь: ${area}`);
        } else {
            alert('Пожалуйста, введите числовые значения для сторон треугольника.');
        }
    }
});
