 // Хранение имен тегов и их описаний
 const tagDescriptions = {
    'html': 'Определяет корневой элемент документа.',
    'head': 'Содержит метаинформацию о документе.',
    'body': 'Содержит содержимое веб-страницы.',
    'div': 'Группирует содержимое документа и предоставляет стиль.',
    'p': 'Определяет абзац текста.',
    'a': 'Определяет гиперссылку.',
    'img': 'Определяет изображение.',
    // Добавьте другие теги и их описания по необходимости
};

function searchTag(event) {
    if (event.key === 'Enter') {
        const tagInput = document.getElementById('tagInput');
        const resultDiv = document.getElementById('result');

        const tagName = tagInput.value.toLowerCase();
        const description = tagDescriptions[tagName];

        if (description) {
            resultDiv.innerHTML = `<p><strong>${tagName}</strong>: ${description}</p>`;
        } else {
            resultDiv.innerHTML = '<p>Тег не найден.</p>';
        }
    }
}