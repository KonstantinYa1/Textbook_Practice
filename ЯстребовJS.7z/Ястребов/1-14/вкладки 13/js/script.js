document.addEventListener('DOMContentLoaded', function () {
    const menuLinks = document.querySelectorAll('.menu a');
  
    menuLinks.forEach(function (link, index) {
      link.addEventListener('click', function (event) {
        event.preventDefault();
  
        // Remove active class from all links and tabs
        menuLinks.forEach(function (menuLink) {
          menuLink.classList.remove('active');
        });
  
        const tabs = document.querySelectorAll('.tabs .tab');
        tabs.forEach(function (tab) {
          tab.classList.remove('active');
        });
  
        // Add active class to the clicked link and corresponding tab
        link.classList.add('active');
        tabs[index].classList.add('active');
      });
    });
  });
  