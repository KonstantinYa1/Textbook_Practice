function handleKeyboardClick(event) {
    if (event.target.classList.contains('key')) {
        const key = event.target.textContent;

        if (key === 'Backspace') {
            // Удаляем последний символ
            inputField.value = inputField.value.slice(0, -1);
        } else if (key === 'Enter') {
            // Добавляем новую строку
            inputField.value += '\n';
        } else {
            // Добавляем символ к текущему значению
            inputField.value += key;
        }
    }
}