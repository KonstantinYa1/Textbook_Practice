document.addEventListener('DOMContentLoaded', function () {
    const countries = ['Belarus', 'Belgium', 'Bulgaria'];
    const input = document.getElementById('country');
    const autocompleteList = document.getElementById('autocomplete-list');

    input.addEventListener('input', function () {
        const inputValue = input.value.toLowerCase();
        const matches = countries.filter(country => country.toLowerCase().startsWith(inputValue));

        autocompleteList.innerHTML = '';

        matches.forEach(match => {
            const listItem = document.createElement('li');
            listItem.textContent = match;
            autocompleteList.appendChild(listItem);

            listItem.addEventListener('click', function () {
                input.value = match;
                autocompleteList.innerHTML = '';
            });
        });
    });
});